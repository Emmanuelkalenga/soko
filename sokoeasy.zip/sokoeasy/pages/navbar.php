<?php require 'pages/action.php';?>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="index.php"><img src="assets/images/icon.jpg" width="155px" height="45"></a>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
    <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="produits.php">Produits</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="contact.php">Contact</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="apropos.php">Apropos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="blog.php">Blog</a>
      </li>
      <li class="nav-item">
         <a class="nav-link icon-shopping_cart" href="panier.php"><?php
    if (creationPanier())
    {
       $nbArticles=count($_SESSION['panier']['libelleProduit']);
       if ($nbArticles <= 0)
       echo "";
       else
       { 
          for ($i=0 ;$i < $nbArticles ; $i++)
          {
 
         
       }?><span class="label text-danger label-warning pull-right"> <?php echo $pr=$i;?></span>
  <?php  }}?>
    
     
 </a>
      </li>
    </ul>
     
  </div>
</nav>
