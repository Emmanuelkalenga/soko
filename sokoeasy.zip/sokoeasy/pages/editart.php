<?php require 'head.php';?>
<?php
	include('class/article.class.php');
 

	include('class/connexion.php');
?>
<?php 
       if (isset($_POST['save'])) {
        
      $id=$_GET['id'];
      $files=$_FILES['img'];
      $filename=$files['name'];
      $fileerror=$files['error'];
      $filetmp=$files['tmp_name'];
      $fileext=explode('.', $filename);
      $filecheck=strtolower(end($fileext));
      $fileextcheck=array('jpg', 'png','jpeg');
        if (in_array($filecheck, $fileextcheck)) {
           $dir='img/'.$filename;
           move_uploaded_file($filetmp, $dir);
      $update = $connexion->prepare('UPDATE article_mboka,categorie_art_mboka SET article_mboka.nom_art=?,article_mboka.detail_article=?,article_mboka.prix_initial=?,article_mboka.poids=?,article_mboka.type_article=?,categorie_art_mboka.description=?,article_mboka.img=? WHERE article_mboka.cat_article=categorie_art_mboka.id_cat AND article_mboka.id_art ="'.$id.'" ');
           $update->execute(array($_POST['nom_art'],$_POST['detail_article'],$_POST['poids'],$_POST['prix'],$_POST['type_article'],$_POST['id_categorie'], $dir));
        ?>
      <script type="text/javascript">
  alert('la'.'categorie a ete enregistre avec succes');
  document.Location='./article.php';
  </script>
  <?php
    
       }  
          ?>  
  <?php  }elseif(isset($_GET['id'])) {
            $id=$_GET['id'];
            $requete=$connexion->query('SELECT article_mboka.nom_art,article_mboka.detail_article,article_mboka.prix_initial,article_mboka.poids,article_mboka.type_article,categorie_art_mboka.description,article_mboka.id_art, article_mboka.img ,categorie_art_mboka.id_cat, article_mboka.cat_article FROM article_mboka,categorie_art_mboka WHERE  id_cat="'.$id.'"');
      while ($Cat_article=$requete->fetch()) {
           ?>
       
	 <div class="container">

        <div class="row justify-content-center">

            <div class="col-md-10">

                <div class="card" style="margin-top: 10px">
                    <form method="POST" class="form-horizontal
                   " action="" enctype="multipart/form-data">
                      <div class="card-header text-center">
                            <p> <strong>Formulaire d'article </strong></p>
                        </div>

                        <div class="card-body">

                            <div class="row">

                                <div class="col-md-12">
                                    <div class="form-group">
 
                                   <input type="text" name="nom_art" class="form-control" value="<?php echo $Cat_article['nom_art'];?>"  placeholder="Nom de l'article">
                                    </div>
                                  <div class="form-group">
                                      <textarea type="text" name="detail_article" class="form-control" placeholder="detaille sur l'article"><?php echo $Cat_article['detail_article'];?> </textarea>
                                  </div>

                                <div class="form-group">
                                  <input type="text" name="poids" value="<?php echo $Cat_article['poids'];?>"  class="form-control" placeholder="poids">
                                </div>
                                <div class="form-group">
                                  <input type="text" name="prix" value="<?php echo $Cat_article['prix_initial'];?>"  class="form-control" placeholder="prix">
                                </div>
                                  <div class="form-group">
<input type="text" value="<?php echo $Cat_article['type_article'];?>"  name="type_article" class="form-control" placeholder="type d'article">
                               </div>
                                
                                    <div class="form-group">  
                                    <select class="form-control" value="<?php echo $Cat_article['description'];?>"  name="id_categorie">   
                                                   <?php
                                                    $affiche= new Article();
                                                    $affiche->affichercategorie($_POST['id_categorie']);
                                                   ?> 
                                    </select>
                                  </div>
                                   <div class="form-group">
                                  <input type="file" name="img" value="<?php echo $Cat_article['img'];?>"  class="form-control" >
                                </div>
                      <div class="form-group">
                        <input type="submit" name="save" class="btn btn-primary btn-block" value="Modifier"></div><?php }} ?>
<?php require 'ft.php';?>