<section class="footer" style="background-image:linear-gradient(to right,#27272b,#27272b);">
<div class="container pt-4 ">
	<div class="row">
		 	<div class="col-md-3 text-secondary text-justify">
				<img src="assets/images/icon.jpg" width="160px" height="60">
				<p>SokoEasy,plateforme destiné à vendre les legumes, les epices et les fruits en ligne. 
              simplifiez vous la vie!  </p>
			</div>
			<div class="col-md-2 ">
				<h2 class="text-secondary">Menu</h2>
				<ul class="list-inline">
					<li><a href="index.php">Accueil</a></li>
					<li><a href="produits.php">Produits</a></li>
					<li><a href="contact.php">Contact</a></li>
					<li><a href="apropos.php">Apropos</a></li>
				</ul>
			</div>
			<div class="col-md-2 ">
				<h2 class="text-secondary">Information</h2>
				<ul class="list-inline">
					<li><a href="#"data-toggle="modal" data-target="#exampleModal">Mode de paiement</a></li>


				</ul>
			</div>
			<div class="col-md-3">
				<h2 class="text-secondary text-center">plus info </h2>
				<div  class="team-member">
				<ul class="list-inline social-buttons">
                        <li class="list-inline-item ">
                          <a href="#">
                            <i class="icon-twitter"></i>
                          </a>
                        </li>
                        <li class="list-inline-item ">
                          <a href="https://web.facebook.com/MbogaApp-113318020357826">
                            <i class="icon-facebook"></i>
                          </a>
                        </li>
                        <li class="list-inline-item ">
                          <a href="#">
                            <i class="icon-instagram"></i>
                          </a>
                        </li>
                  </ul>
			</div>
		</div>
		 
	</div>
</div>
</section>
<hr>
<div class="container pb-0">
	<div class="row justify-content-center ">
		 
			<ul class="list-inline">
			<li class="list-inline-item  "><a href="#"><i class="icon-facebook text-secondary "></i></a></li>
			 
			<li class="list-inline-item "><a href="#"><i class="icon-instagram text-secondary"></i></a></li>
			 
			<li class="list-inline-item "><a href="#"><i class="icon-twitter text-secondary"></i></a></li>
			</ul>
		</div>
	</div>
</div>
 


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Mode de paiement</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Payer en liquide ou par cheque barre à la reception de votre commande, Munissez vous d'une piece d'identite. Un recu peut etre emis par le livreur 
                Cheque au nom de Biac 
                En cas d'abus , nous nous reservons le droit de bloquer les commandes provenant de votre Email</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">fermer</button>
         
      </div>
    </div>
  </div>
</div>


</div>
</body>
<script type="text/javascript">
    $('#slider-area').owlCarousel({
    loop:true,
     autoplay:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})
</script>
<script type="text/javascript">
    $('.navTrigger').click(function () {
    $(this).toggleClass('active');
    console.log("Clicked menu");
    $("#mainListDiv").toggleClass("show_list");
    $("#mainListDiv").fadeIn();

});

</script>
<script>
        $(window).scroll(function() {
            if ($(document).scrollTop() > 50) {
                $('.nav').addClass('affix');
                console.log("OK");
            } else {
                $('.nav').removeClass('affix');
            }
        });
    </script>
</html>

