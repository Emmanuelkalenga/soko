<?php
	include('class/cat_article.class.php');

	include('class/connexion.php');
?>
<?php require 'head.php';?>
<?php 
			 if (isset($_POST['save'])) {
			 	
			$id=$_GET['id'];
			$files=$_FILES['img'];
			$filename=$files['name'];
			$fileerror=$files['error'];
			$filetmp=$files['tmp_name'];
			$fileext=explode('.', $filename);
			$filecheck=strtolower(end($fileext));
			$fileextcheck=array('jpg', 'png','jpeg');
				if (in_array($filecheck, $fileextcheck)) {
					 $dir='img/'.$filename;
					 move_uploaded_file($filetmp, $dir);
			$update = $connexion->prepare('UPDATE categorie_art_mboka SET description = ?, img = ? WHERE id_cat ="'.$id.'" ');
	         $update->execute(array($_POST['designation'], $dir));
			  ?>
			<script type="text/javascript">
	alert('la'.'categorie a ete enregistre avec succes');
	document.Location='./categorie_article.php';
	</script>
	<?php
		
			 }	
					?>	
	<?php  }elseif(isset($_GET['id'])) {
            $id=$_GET['id'];
           	$requete=$connexion->query('SELECT * FROM categorie_art_mboka where id_cat="'.$id.'"');
			while ($Cat_article=$requete->fetch()) {
           ?>
	<div class="container">

        <div class="row justify-content-center">

            <div class="col-md-9">

                <div class="card" style="margin-top: 10px">
		<form method="POST" action="" enctype="multipart/form-data" class="form-horizontal">
                  <div class="box-body">
			<div class="card-header text-center">
                            <p> <strong>Formulaire de categorie article</strong></p>
                        </div>

                        <div class="card-body">

                            <div class="row">

                                <div class="col-md-12">
                                    <div class="form-group">
			 							<input type="text" name="designation" placeholder="designation" value="<?php echo $Cat_article['description'];?>" class="form-control" required/>
                 
                                   </div>
                                   <div class="form-group">
			 							<input type="file" name="img"  class="form-control" value="<?php echo $Cat_article['img'];?>" required/>
                 
                                   </div>
								<?php } }?>		
			<div class="form-group">
			 <input type="submit" name="save" value="UPDATE" class="btn btn-primary btn-block"> </div>
			 
	</form></div></div>
<?php require 'ft.php';?>